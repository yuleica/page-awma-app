exports.id = 799;
exports.ids = [799];
exports.modules = {

/***/ 3799:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "Otro_container__7rjbC",
	"main": "Otro_main__h75rs",
	"header": "Otro_header__j4amt",
	"divinterno": "Otro_divinterno__cTh5y",
	"title": "Otro_title__YL2T9",
	"titleawma": "Otro_titleawma__egbSO",
	"description": "Otro_description__XPsKq",
	"grid": "Otro_grid__po0N8",
	"headerlogo": "Otro_headerlogo__SEDvA",
	"nav": "Otro_nav__xR3Kn",
	"li": "Otro_li__O5The",
	"divseccion": "Otro_divseccion__5_Ykw",
	"card": "Otro_card__jcUTK",
	"cardawma1": "Otro_cardawma1__jOPzu",
	"cardawma2": "Otro_cardawma2__56jfO",
	"gridawma": "Otro_gridawma__Fd5JB",
	"descriptionawma": "Otro_descriptionawma__M4cSQ",
	"logo": "Otro_logo__FXHl_",
	"boton": "Otro_boton__x32j6",
	"footer": "Otro_footer__TIQXm",
	"cierre": "Otro_cierre__LgX_z",
	"plogo": "Otro_plogo__bPFIa",
	"cardawmap": "Otro_cardawmap__0PzLO",
	"code": "Otro_code__u6Rgb"
};


/***/ })

};
;